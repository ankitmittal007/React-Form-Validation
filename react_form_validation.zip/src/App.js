import React, { Component } from 'react';
import logo from './logo.svg';
import 'bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap/dist/css/bootstrap-theme.css';
import './App.css';

class App extends Component {
  constructor(props){
    super(props);
    this.state={
      email:'',
      password:'',
      contact:'',
      username:'',
      formerrors:{
        emailvalid:'',
        contactvalid:'',
        pwdvalid:''
      },
      emailvalid:false,
      contactvalid:false,
      pwdvalid:false,
      formvalid:false
    }
  }

  formValidations=(e)=>{
    const name=e.target.name;
    const value=e.target.value;
    console.log('Form event----',e);
    this.setState({
      [e.target.name] : e.target.value
    },()=>{
      this.validateField(name,value);
    });
  }
  validateField =(fieldName,value)=>{
    let emailvalid=this.state.emailvalid;
    let contactvalid=this.state.contactvalid;
    let pwdvalid=this.state.pwdvalid;
    let formerrors=this.state.formerrors;
    console.log(fieldName,value)
    switch(fieldName){
      case 'email':{
        let regexemail=/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i;

        emailvalid=regexemail.test(value)
        console.log("Email validation----",emailvalid);
        formerrors.emailvalid=emailvalid? '' : 'email is invalid';
        break;
      }
      case 'password':{
        pwdvalid = value.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}$/)
        formerrors.pwdvalid=pwdvalid? '' : 'Password is invalid';
        break;
      }
     
    }
     this.setState({
        formerrors:formerrors,
        emailvalid:emailvalid,
        pwdvalid:pwdvalid
      },this.validateForm);

  }

  validateForm =() =>{
    this.setState({
      formvalid: this.state.emailvalid && this.state.pwdvalid
    });
  }
  errorClass =(formerrorfield)=>{
    console.log("formerrorfield----",formerrorfield)
    return (formerrorfield.length===0? '':'has-error');
  }
  render() {
    return (
      <div className="container-fluid App">
        <header className="App-header">
          {/* <img src={logo} className="App-logo" alt="logo" /> */}
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <form name="demoform">
        <div className="col-md-6 col-sm-6">
          <div className="form-group">
            <label htmlFor="username">UserName</label>
            <input type="text" className="form-control" onChange={(e)=>this.formValidations(e)} value={this.state.username} name="username" />
          </div>
          <div className={this.state.formerrors.emailvalid? 'form-group has-error':'form-group'}>
            <label htmlFor="email">Email address</label>
            <input type="email" className="form-control" onChange={(e)=>this.formValidations(e)} value={this.state.email} name="email" />
          </div>
          <p className={this.state.formerrors.emailvalid? 'has-error':'hide-element'}>Invalid email</p>
          <div className="form-group">
            <label htmlFor="contact">Contact</label>
            <input type="text" className="form-control" onChange={(e)=>this.formValidations(e)} value={this.state.contact} name="contact" />
          </div>
          <p className={this.state.formerrors.contactvalid? 'has-error':'hide-element'}>Contactno should be in the form +countrycode(2digits)-10 digits</p>
          <div className={this.state.formerrors.pwdvalid? 'form-group has-error':'form-group'}>
            <label htmlFor="password">Password</label>
            <input type="password" className="form-control" onChange={(e)=>this.formValidations(e)} value={this.state.password} name="password" />
          </div>
          <p className={this.state.formerrors.pwdvalid? 'help-block':'hide-element'}>Password should contain atleast 1 special,1 lowercase,1 uppercase and should be atleast 6 characters long.</p>
          <button type="submit" className="btn btn-primary" disabled={!this.state.formvalid}>Submit</button>
        </div>
        </form>
      </div>
    );
  }
}

export default App;
